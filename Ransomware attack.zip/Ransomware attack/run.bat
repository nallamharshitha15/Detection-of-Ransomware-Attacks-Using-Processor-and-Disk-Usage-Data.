python Main.py
pause